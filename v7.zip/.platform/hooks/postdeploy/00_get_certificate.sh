﻿
# Place in .platform/hooks/postdeploy directory
sudo certbot -n -d PasTime.us-east-1.elasticbeanstalk.com --nginx --agree-tos --email ejoaquin@byu.edu